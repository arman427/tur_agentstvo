import { CatalogBody } from '@/components';
import { db } from '@/lib/prisma';

export default async function CatalogPage() {
   const toursData = await db.tour.findMany({
      orderBy: { id: 'asc' },
   });

   return (
      <>
         <CatalogBody items={toursData} />
      </>
   );
}
