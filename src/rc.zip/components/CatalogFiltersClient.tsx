"use client";

import { useSet } from "@/hooks/useSet";
import { CatalogFilters } from "./CatalogFilters";
import qs from "qs";
import { useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";

interface Props {
   className?: string
}

export function CatalogFiltersClient({ className }: Props) {
   const [selectedFilters, { toggle, has }] = useSet<string>();
   const router = useRouter();
   const pathname = usePathname();

   useEffect(() => {
      const filters = {
         filters: Array.from(selectedFilters)
      };

      const queryString = qs.stringify(filters, { arrayFormat: "comma" });

      const timeOutId = setTimeout(() => {
         router.push(`${pathname}?${queryString}`, { scroll: false })
      }, 200);
      return () => clearTimeout(timeOutId);
   }, [selectedFilters]);

   return (
      <CatalogFilters
         onToggle={toggle}
         has={has}
      />
   );
}